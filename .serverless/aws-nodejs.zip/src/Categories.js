import React, { Component } from 'react';
import {Link, withRouter} from 'react-router';
import './App.css';

class Categories extends Component {
  render() {
    return (
      <div className="App">
        Categories
      </div>
    );
  }
}

export default withRouter(Categories);
